class X {
   static int a = 1, b = 2;
   public static void main(String arg[]) 
   {
      int x = 3, y = 4, z;

      z = f(a, b, x, y);
   }
   public static int f(int a, int b, int x, int y)
   {
      ireturn (a + a + b + x - y);
   }
}

#include <iostream>
using namespace std;
void f()
{
   int x, y, z;
   cout << "Enter 3 integers\n";
   cin >> x >> y >> z;
   cout << x << y << z << endl;
}
int main()
{
   f();
   return 0;
}        
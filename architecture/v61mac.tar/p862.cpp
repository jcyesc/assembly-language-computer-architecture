#include <iostream>
using namespace std;
int x, y;
int main()
{
   cout << "enter\n";
   cin >> x;
   cout << "enter\n";
   cin >> y;
   if (x >= y)
      cout << "hello\n";
   else
      cout << "bye\n";
   return 0;
}

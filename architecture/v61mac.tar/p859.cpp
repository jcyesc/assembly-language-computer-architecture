#include <iostream>
using namespace std;
int x = 1;
int main()
{
   do {
      cout << "hello\n";
   } while (x++ != 10);
   return 0;
}

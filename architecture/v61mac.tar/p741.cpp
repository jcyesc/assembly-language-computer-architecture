#include <iostream>
using namespace std;
int main()
{
   int x;
   int y = 3;
   x = y + 5;
   cout << "x = " << x << endl;
   cout << "y = " << y << endl;
   return 0;
}        
class X {
   public static void main(String arg[]) {
      int x;
      x = 1;
      x = 5;
   }
}

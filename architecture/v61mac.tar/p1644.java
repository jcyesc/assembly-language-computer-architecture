class X {
   public static void main(String arg[]) 
   {
      int i, x = 0;
      for (i = 0; i < 5; i++) 
         x++;
   }
}

#include <iostream>
using namespace std;
int i = 20;
int main(void)
{
   do {
      cout << "hello\n";
      i--;
   } while (i > 0);
   return 0;
}

#include <iostream>
using namespace std;
int x = 1;
int main()
{
   while (++x + 2 < 20)
      cout << "hello\n";
   return 0;
}

class X {
   public static void main(String arg[]) 
   {
     f(3);
   }
   public static void f(int a)
   {
      a = 1;
   }
}
